/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java2ddrawingapplication;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.sound.sampled.Line;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 *
 * @author Julian Renner
 * Description: Create a 2D Drawing Application in Java that matches the one prompted in the assignment and is fully functional.
 * Date: 10/20/2023
 */
public class DrawingApplicationFrame extends JFrame implements ActionListener
{
    // Create the panels for the top of the application. One panel for each
    // line and one to contain both of those panels.
    JPanel firstLine;
    JPanel secondLine;
    JPanel topPanel;
    // create the widgets for the firstLine Panel.
    JComboBox chooseShape;
    String[] shapes = {"Line","Rectangle","Oval"};
    private ArrayList<MyShapes> shapesList = new ArrayList<>();
    String selectedShapeType = "Line";
    JButton firstColor;
    JButton secondColor;
    JButton undo;
    JButton clear;
    //create the widgets for the secondLine Panel.
    JCheckBox filledCheckBox;
    JCheckBox gradientCheckBox;
    JCheckBox dashCheckBox;
    JSpinner lineWidthSpinner;
    JSpinner dashLengthSpinner;
    
    // Variables for drawPanel.
    int lineWidth;
    int dashLength;
    float[] dashArray;
    Stroke stroke = new BasicStroke(10);  
    Color color1 = Color.BLACK;
    Color color2 = Color.BLACK;
    Paint paint = color1;

    // add status label
    JLabel status;
    
   
    // Constructor for DrawingApplicationFrame 
    public DrawingApplicationFrame()
    {
        // add widgets to panels
        this.setTitle("Java 2D Drawings");
        DrawPanel drawPanel = new DrawPanel();
        drawPanel.setBackground(Color.WHITE);        
        status = new JLabel(" (x, y)");
        
        // firstLine widgets (shape, select, 1st col, 2nd col, undo, clear
        firstLine = new JPanel();
        firstLine.add(new JLabel("Shape: "));
        chooseShape = new JComboBox(shapes);
        firstLine.add(chooseShape);
        chooseShape.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            selectedShapeType = (String) chooseShape.getSelectedItem();
        }
    });
        firstColor = new JButton("1st Color...");
        secondColor = new JButton("2nd Color...");
        undo = new JButton("Undo");
        clear = new JButton("Clear");
        firstLine.setBackground(Color.CYAN);
        firstLine.add(firstColor);
        firstLine.add(secondColor);
        firstLine.add(undo);
        firstLine.add(clear);

        // secondLine widgets (opt: filled, gradi, dash, li width, dash length
        secondLine = new JPanel();
        secondLine.setBackground(Color.CYAN);
        filledCheckBox = new JCheckBox("Filled");
        gradientCheckBox = new JCheckBox("Use Gradient");
        dashCheckBox = new JCheckBox("Dashed");
        lineWidthSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 99, 1));
        dashLengthSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 99, 1));
        
        
        secondLine.add(new JLabel("Options: "));
        secondLine.add(filledCheckBox);
        secondLine.add(gradientCheckBox);
        secondLine.add(dashCheckBox);
        secondLine.add(new JLabel("Line Width: "));
        secondLine.add(lineWidthSpinner);
        secondLine.add(new JLabel("Dash Length: "));
        secondLine.add(dashLengthSpinner);
        
        // add top panel of two panels
        topPanel = new JPanel();
        topPanel.setBackground(Color.CYAN);
        topPanel.setLayout(new GridLayout(2,0));
        topPanel.add(firstLine);
        topPanel.add(secondLine);
        
        // add topPanel to North, drawPanel to Center, and statusLabel to South
        this.add(topPanel,BorderLayout.NORTH);
        this.add(drawPanel,BorderLayout.CENTER);
        this.add(status, BorderLayout.SOUTH);
        
        //add listeners and event handlers
        firstColor.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
           color1 = JColorChooser.showDialog(null, "Choose a Color", Color.WHITE);
           firstColor.setBackground(color1);
           if (gradientCheckBox.isSelected()){
                    paint = new GradientPaint(0,0,color1,50,50,color2,true);
                }
                else{
                    paint = color1;
                }
           repaint();
        }
    });
        secondColor.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
           color2 = JColorChooser.showDialog(null, "Choose a Color", Color.WHITE);
           secondColor.setBackground(color2);
           if (gradientCheckBox.isSelected()){
                    paint = new GradientPaint(0,0,color1,50,50,color2,true);
                }
                else{
                    paint = color1;
                }
           repaint();
        }
    });       
        undo.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!shapesList.isEmpty()) {
                shapesList.remove(shapesList.size() - 1); 
                drawPanel.repaint();
                }
        }
    });        
        clear.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!shapesList.isEmpty()) {
                shapesList.clear();  
                drawPanel.repaint();
                }
        }

        });
        filledCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                
            }
        });
        gradientCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (gradientCheckBox.isSelected()){
                    paint = new GradientPaint(0,0,color1,50,50,color2,true);
                }
                else{
                    paint = color1;
                }
                repaint();
            }
        });
        dashCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (dashCheckBox.isSelected())
            {
                stroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dashArray, 0);
                repaint();
            } else
            {
                stroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
                repaint();
            }
              
            }
        });
        lineWidthSpinner.addChangeListener(new ChangeListener() {
    @Override
    public void stateChanged(ChangeEvent e) {
        lineWidth = (Integer) lineWidthSpinner.getValue();
        if (dashCheckBox.isSelected()) {
            stroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dashArray, 0);
        } else {
            stroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        }
        repaint();
    }
});
        dashLengthSpinner.addChangeListener(new ChangeListener() {
    @Override
    public void stateChanged(ChangeEvent e) {
        dashLength = (Integer) dashLengthSpinner.getValue();
        dashArray = new float[]{(float) dashLength};
        if (dashCheckBox.isSelected()) {
            stroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dashArray, 0);
        } else {
            stroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        }
        repaint();
    }
});
        
    }
    
    // Create event handlers, if needed
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
           
    
    // Create a private inner class for the DrawPanel.
private class DrawPanel extends JPanel {
    private MyShapes currentShape;

    public DrawPanel() {
        addMouseListener(new MouseHandler());
        addMouseMotionListener(new MouseHandler());
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Loop through and draw each shape in the shapes array list
        for (MyShapes shape : shapesList) {
            shape.draw(g2d);
        }

        // This will draw the current shape being drawn (if it is not null).
        if (currentShape != null) {
            currentShape.draw(g2d);
        }
    }

    private class MouseHandler extends MouseAdapter implements MouseMotionListener {
        private Point startPoint; // This is used to store the initial mouse click location.

        @Override
        public void mousePressed(MouseEvent event) {
            startPoint = event.getPoint(); // Stores the initial mouse click location.
            //creates the shape depending on multiple different variables.
            if (selectedShapeType.equals("Line")) {
                currentShape = new MyLine(startPoint, startPoint, paint, stroke);
            } else if (selectedShapeType.equals("Rectangle")) {
                currentShape = new MyRectangle(startPoint, startPoint, paint, stroke, filledCheckBox.isSelected());
            } else if (selectedShapeType.equals("Oval")) {
                currentShape = new MyOval(startPoint, startPoint, paint, stroke, filledCheckBox.isSelected());
            }
        }

        @Override
        public void mouseReleased(MouseEvent event) {
            //Adds the shape to the draw panel once released.
            if (currentShape != null) {
                currentShape.setEndPoint(event.getPoint()); 
                shapesList.add(currentShape); 
                currentShape = null;
                repaint(); 
            }
        }

        @Override
        public void mouseDragged(MouseEvent event) {
            // Update the end point of the current shape while dragging. This allows the shapes and the coordinates to be visible.
            if (currentShape != null) {
                currentShape.setEndPoint(event.getPoint());
                int x = event.getX();
                int y = event.getY();
                status.setText(" (" + x + ", " + y + ")");
                repaint(); // Redraw the panel to show the shape being drawn
            }
        }

        @Override
        public void mouseMoved(MouseEvent event) {
            //This updates the coordinates of status variable while not dragging.
            int x = event.getX();
            int y = event.getY();
            status.setText(" (" + x + ", " + y + ")");
            repaint();
        }
        
    }
}

}
